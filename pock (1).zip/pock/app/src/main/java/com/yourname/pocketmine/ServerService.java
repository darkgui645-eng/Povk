package com.yourname.pocketmine;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import java.io.File;
import java.io.IOException;

public class ServerService extends Service {
    static Process serverProcess;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, createNotification());
        startServer();
        return START_STICKY;
    }

    // Cria notificação enquanto o servidor está rodando
    private Notification createNotification() {
        String channelId = "PocketMineChannel";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Servidor PMMP", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        return new Notification.Builder(this, channelId)
                .setContentTitle("PocketMine App")
                .setContentText("Servidor rodando")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();
    }

    // Método que inicia o servidor
    private void startServer() {
        try {
            // Caminho da pasta assets
            File assetsDir = new File(getFilesDir(), "assets");

            // Garantir que o start.sh seja executável
            File startFile = new File(assetsDir, "start.sh");
            startFile.setExecutable(true);

            // Inicia o PocketMine via start.sh
            ProcessBuilder pb = new ProcessBuilder("./start.sh");
            pb.directory(assetsDir);
            pb.redirectErrorStream(true);
            serverProcess = pb.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Método para parar o servidor
    public static void stopServer() {
        if (serverProcess != null) {
            serverProcess.destroy();
        }
    }
}
#!/system/bin/sh
DIR="$(dirname "$0")"
cd "$DIR"

# Rodar PHP embutido do assets
./php-bin/php PocketMine-MP.phar